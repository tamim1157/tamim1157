//
//  ViewController.swift
//  1907060
//
//  Created by kuet on 11/10/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var text1: UITextField!
    
    @IBOutlet weak var btn: UIButton!
    @IBOutlet weak var text2: UITextField!
    
    @IBOutlet weak var img: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        img.image = UIImage(imageLiteralResourceName: "Cardiac")
    }


    @IBAction func Button(_ sender: Any) {
        btn.setTitle("signed in", for: .normal)
    }
    
}

